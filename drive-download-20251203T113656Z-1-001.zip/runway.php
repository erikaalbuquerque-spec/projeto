<?php
// video.php
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Desfile Balenciaga</title>
    <style>
        body {
            margin: 0;
            background-color: black;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            overflow: hidden;
            position: relative;
            font-family: Arial, sans-serif;
        }

        /* Efeito de blur branco nas bordas */
        body::before {
            content: "";
            position: absolute;
            top: -50px;
            left: -50px;
            right: -50px;
            bottom: -50px;
            background: radial-gradient(circle, rgba(255,255,255,0.08) 0%, rgba(0,0,0,1) 70%);
            filter: blur(60px);
            z-index: 0;
        }

        /* Botão voltar */
        .top-bar {
            position: absolute;
            top: 20px;
            left: 20px;
            z-index: 2;
        }

        .btn-voltar {
            padding: 10px 20px;
            background: none;
            color: white;
            border: none;
            font-size: 18px;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .btn-voltar:hover {
            color: #aaa;
        }

        /* Container do vídeo centralizado */
        .video-container {
            z-index: 1;
            width: 70%;
            max-width: 700px;
            aspect-ratio: 16 / 9;
        }

        .video-container iframe {
            width: 100%;
            height: 100%;
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.2);
        }

        @media (max-width: 768px) {
            .video-container {
                width: 90%;
                max-width: 500px;
            }
        }
    </style>
</head>
<body>

    <div class="top-bar">
        <button class="btn-voltar" onclick="window.location.href='index.php'">← Voltar para Loja</button>
    </div>

    <div class="video-container">
        <iframe
            src="https://www.youtube.com/embed/9QMugKSXFWQ?autoplay=1&mute=1&controls=0&modestbranding=1&showinfo=0&rel=0"
            title="Desfile Balenciaga"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowfullscreen>
        </iframe>
    </div>

</body>
</html>
