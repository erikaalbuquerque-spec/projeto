<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['endereco'] = $_POST['endereco'] ?? '';
    $_SESSION['cartao'] = $_POST['cartao'] ?? '';
    $_SESSION['cvv'] = $_POST['cvv'] ?? '';
    $_SESSION['pedido_finalizado'] = true;

    // Redireciona para a tela de confirmação estilizada
    header('Location: pedido_confirmado.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Finalizar Pedido - New Way</title>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
    }

    html, body {
        height: 100%;
        overflow: hidden;
    }

    /* Fundo com vídeo */
    .video-background {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
        z-index: -1;
        filter: blur(10px) brightness(0.7);
    }

    .video-background iframe {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 120%;
        height: 120%;
        transform: translate(-50%, -50%);
        pointer-events: none;
        opacity: 0.7;
    }

    /* Container principal */
    .container {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 450px;
        background: rgba(255, 255, 255, 0.65);
        backdrop-filter: blur(20px);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
        box-shadow: 0 0 25px rgba(0,0,0,0.2);
        animation: fadeIn 1.2s ease forwards;
        opacity: 0;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateX(-50%) translateY(30px); }
        to { opacity: 1; transform: translateX(-50%) translateY(0); }
    }

    /* Logo */
    h1 {
        position: absolute;
        top: 100px;
        font-size: 30px;
        letter-spacing: 6px;
        color: #000;
        font-weight: 600;
    }

    /* Formulário */
    form {
        width: 80%;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-top: 40px;
    }

    label {
        align-self: flex-start;
        color: #000;
        font-weight: 500;
        margin-top: 15px;
    }

    input {
        width: 100%;
        padding: 12px;
        margin-top: 5px;
        border: none;
        border-radius: 6px;
        background: rgba(240, 240, 240, 0.9);
        outline: none;
        font-size: 15px;
        transition: 0.3s;
    }

    input:focus {
        background: white;
        box-shadow: 0 0 8px rgba(0,0,0,0.15);
    }

    button {
        margin-top: 30px;
        width: 100%;
        padding: 12px;
        background: #000;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    button:hover {
        background: white;
        color: black;
        transform: translateY(-3px);
    }

</style>
</head>
<body>

<!-- Fundo com vídeo -->
<div class="video-background">
    <iframe src="https://www.youtube.com/embed/m1iTy0zJ8dU?si=4zQbKwac_oWWSL69&controls=0&start=10&autoplay=1&mute=1&loop=1&playlist=m1iTy0zJ8dU"
    title="YouTube video player" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>

<!-- Container com formulário -->
<div class="container">
    <h1>NEW WAY</h1>
    <form method="POST">
        <label>Endereço de entrega:</label>
        <input type="text" name="endereco" required>

        <label>Número do cartão:</label>
        <input type="text" name="cartao" required>

        <label>CVV:</label>
        <input type="text" name="cvv" required>

        <button type="submit">Confirmar Pedido</button>
    </form>
</div>

</body>
</html>

